<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class records extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    public function dashboard(){
        if(!empty($this->session->userdata('r_name'))||isset($_SESSION['r_name'])){
            $this->load->view('records/dashboard');
        }else{
            redirect(base_url());
        }
    }
    public function show_records(){
        $records['res']=$this->db->get('patients')->result();
        $this->load->view('records/records',$records);
    }
    public function new_patient(){
        $this->load->view('records/new_patient');
    }
    public function add_record(){
        $this->load->library('form_validation');

        if($this->input->post('pat_type')=='Student'){
            //$this->form_validation->set_error->delimiters('<div class="error">', '</div>');
            $this->form_validation->set_rules('name','Patient Name','required|alpha|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('age','Age','required|numeric|min_length[0]|max_length[100]');
            $this->form_validation->set_rules('kin_no','Kin Phone No.','required|numeric|exact_length[10]');
            $this->form_validation->set_rules('kin_name','Relative','required|alpha|min_length[3]|max_length[30]');
        
            if($this->form_validation->run()==TRUE){
                $pat_name=$this->input->post('name');
                $age=$this->input->post('age');
                $gender=$this->input->post('gender');
                $pat_type=$this->input->post('pat_type');
                $visit_type=$this->input->post('visit_type');
                $kin_no=$this->input->post('kin_no');
                $relative=$this->input->post('kin_name');
                $stud_idno=$this->input->post('stud_idno');
                $pat_data=array('name'=>$pat_name,'age'=>$age,'gender'=>$gender,'patient_type'=>$pat_type,'visit_type'=>$visit_type,'student_id'=>$stud_idno);
                $this->load->model('records_');
                $pat_added=$this->records_->add_student($pat_data);
                if($pat_added==TRUE){
                    $this->session->set_flashdata('err_entry','Success entry!');
                    $this->load->model('records_');
                    $visit_date=gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*+3);
                    $added_by=$this->session->userdata('r_name');
                    $history_data=array('name'=>$pat_name,'age'=>$age,'gender'=>$gender,'patient_type'=>$pat_type,'visit_type'=>$visit_type,'patient_id'=>$stud_idno,'visit_date'=>$visit_date,'added_by'=>$added_by);
                    $add_history=$this->records_->insert_pat_history($history_data);
                    if($add_history==true){
                        $this->show_records();
                    }else{
                        $this->session->set_flashdata('err_entry','Failed to add patient to history!');
                        $this->load->view('records/new_patient');
                    }

                }else{
                    $this->session->set_flashdata('err_entry','Invalid entry!');
                    $this->load->view('records/new_patient');
                }
                 
            }else{
                $this->session->set_flashdata('err_entry','Invalid entry!');
                $this->load->view('records/new_patient');

            }
                
        }else if($this->input->post('pat_type')=='Non-Student'){
            //$this->form_validation->set_error->delimiters('<div class="error">', '</div>');
            $this->form_validation->set_rules('name','Patient Name','required|alpha|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('age','Age','required|numeric|min_length[0]|max_length[100]');
            $this->form_validation->set_rules('kin_no','Kin Phone No.','required|numeric|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('kin_name','Relative','required|min_length[3]|max_length[30]|alpha');
            $this->form_validation->set_rules('pat_idno','National ID No.','numeric|exact_length[8]');
        
            if($this->form_validation->run()==TRUE){
                $pat_name=$this->input->post('name');
                $age=$this->input->post('age');
                $gender=$this->input->post('gender');
                $pat_type=$this->input->post('pat_type');
                $visit_type=$this->input->post('visit_type');
                $kin_no=$this->input->post('kin_no');
                $relative=$this->input->post('kin_name');
                $pat_idno=$this->input->post('pat_idno');
                $price=$this->input->post('price');

                $pat_data=array('name'=>$pat_name,'age'=>$age,'gender'=>$gender,'patient_type'=>$pat_type,'visit_type'=>$visit_type,'nat_id'=>$pat_idno);
                $this->load->model('records_');
                $pat_added=$this->records_->add_non_student($pat_data);
                if($pat_added==TRUE){
                    $this->session->set_flashdata('err_entry','Success entry!');
                    $this->load->model('records_');
                    $visit_date=gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*+3);
                    $added_by=$this->session->userdata('r_name');
                    $history_data=array('name'=>$pat_name,'age'=>$age,'gender'=>$gender,'patient_type'=>$pat_type,'visit_type'=>$visit_type,'patient_id'=>$pat_idno,'visit_date'=>$visit_date,'added_by'=>$added_by);
                    $add_history=$this->records_->insert_pat_history($history_data);
                    if($add_history==true){
                        $this->show_records();
                    }else{
                        $this->session->set_flashdata('err_entry','Failed to add patient to history!');
                        $this->load->view('records/new_patient');
                    }
                }else{
                    $this->session->set_flashdata('err_entry','Invalid entry!');
                    $this->load->view('records/new_patient');
                }
                
            }else{
                $this->session->set_flashdata('err_entry','Invalid entry-2!');
                $this->load->view('records/new_patient');
            }
        }
        
    }
}
