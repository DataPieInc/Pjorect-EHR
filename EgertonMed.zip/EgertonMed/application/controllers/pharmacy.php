<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pharmacy extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    public function dashboard(){
        if(!empty($this->session->userdata('p_name'))||isset($_SESSION['p_name'])){
            $this->load->view('pharmacy/dashboard');
        }else{
            redirect(base_url());
        }
    }
    public function view_queue(){
        if(!empty($this->session->userdata('p_name'))||isset($_SESSION['p_name'])){
            $data['res']=$this->db->get_where('patient_history',array('to_pharmacy'=>'Pending'))->result();
            $this->load->view('pharmacy/view_queue',$data);
        }else{
            redirect(base_url());
        }
    }
    public function view_prescription($patient_id){
        $data['res']=$this->db->get_where('pharmacy',array('patient_id'=>$patient_id,'status'=>'Pending'))->result();
        $this->load->view('pharmacy/view_patient_prescription',$data);
    }
    public function prescription_given(){
        if(isset($_POST['prescription_seen'])&&$_POST['prescription_seen']){
            $pharmacist_id=$this->input->post('pharmacist_id');
            $patient_id=$this->input->post('patient_id');
            //echo $pharmacist_id.' '.$patient_id;
            $update=array('patient_id'=>$patient_id,'status'=>'Pending');
            $this->load->model('pharmacy_');
            
			$patient_history_updated=$this->pharmacy_->update_patient_history($patient_id);
			if($patient_history_updated==TRUE){
				$pres_given=$this->pharmacy_->prescription_seen($update,$pharmacist_id);
				if($pres_given==TRUE){
                $this->session->set_flashdata('prescription','Prescription given to patient.');
                $data['res']=$this->db->get_where('pharmacy',array('patient_id'=>$patient_id,'status'=>'Served'))->result();
                $this->load->view('pharmacy/view_patient_prescription',$data);
            }
			}
            
        }else{
            $this->view_queue();
        }
    }
}