<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');

	}
	public function index(){
		$this->load->view('home');
	}
	public function login(){
		$username=$this->input->post('username');
		$password=$this->input->post('password');
                $user_type=  $this->input->post('user_type');
		if(!empty($username)||!empty($password)){
			if($user_type=="Admin"){
                $user=$this->db->get_where('admin',array('email'=>$username,'password'=>$password))->result();
                foreach ($user as $r) {
				    $u_name=$r->username;
                     $u_id=$r->id;
                }
                if(!empty($user)){
				    $this->session->set_flashdata('msg','Success');
				    $this->session->set_userdata(array('adm_name'=>$u_name,'adm_id'=>$u_id));
				    $_SESSION['adm_name']=$u_name;
                    $_SESSION['adm_id']=$u_id;
				    $this->load->view('admin/dashboard',$user);

				}
            }else if($user_type=="Records Officer"){
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Records Officer'))->result();
                //if($user==TRUE){
                foreach ($user as $r){
                    $r_name=$r->name;
                    $r_id=$r->id;
                }
                if(!empty($user)){
                    //$this->session->set_flashdata('msg',$u_name);
                    $this->session->set_userdata(array('r_name'=>$r_name,'r_id'=>$r_id));
                    $_SESSION['r_name']=$r_name;
                    $_SESSION['r_id']=$r_id;
                    $this->load->view('records/dashboard',$user);
                }else{
                    $this->session->set_flashdata('msg','Incorrect details-l!');
                    redirect(base_url());
                }
                            
                           
            }else if($user_type=="Doctor"){
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Doctor'))->result();
                //if($user==TRUE){
                foreach ($user as $r){
                    $d_name=$r->name;
                    $d_id=$r->id;
                }
                if(!empty($user)){
                    //$this->session->set_flashdata('msg',$u_name);
                    $this->session->set_userdata(array('d_name'=>$d_name,'d_id'=>$d_id));
                    $_SESSION['d_name']=$d_name;
                    $_SESSION['d_id']=$d_id;
                    $this->load->view('doctor/dashboard',$user);
                }else{
                    $this->session->set_flashdata('msg','Incorrect details-l!');
                    redirect(base_url());
                }


            }
            else if($user_type=="Lab Officer"){
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Lab Officer'))->result();
                //if($user==TRUE){
                foreach ($user as $r){
                    $u_name=$r->name;
                    $u_id=$r->id;
                }
                if(!empty($user)){
                    //$this->session->set_flashdata('msg',$u_name);
                    $this->session->set_userdata(array('l_name'=>$u_name,'l_id'=>$u_id));
                    $_SESSION['l_name']=$u_name;
                    $_SESSION['l_id']=$u_id;
                    $this->load->view('lab/dashboard',$user);
                }else{
                    $this->session->set_flashdata('msg','Incorrect details-l!');
                    redirect(base_url());
                }


            }/*else if($user_type=="Finance Officer"){
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Finance Officer'))->result();
                //if($user==TRUE){
                foreach ($user as $r){
                    $u_name=$r->name;
                    $u_id=$r->id;
                }
                if(!empty($user)){
                    //$this->session->set_flashdata('msg',$u_name);
                    $this->session->set_userdata(array('f_name'=>$u_name,'f_id'=>$u_id));
                    $_SESSION['f_name']=$u_name;
                    $_SESSION['f_id']=$u_id;
                    $this->load->view('finance/dashboard',$user);
                }else{
                    $this->session->set_flashdata('msg','Incorrect details-l!');
                    redirect(base_url());
                }
                
                
            }*/else if($user_type=="Pharmacist"){
                /*$user=$this->db->query("SELECT * FROM employees WHERE email='".$username."'AND password='".$password."'AND");
                if($user->num_rows()>0){
                    foreach ($user->result() as $r){
                        $u_name=$r->name;
                        $u_id=$r->id;
                    }
                    if(!empty($user)){
                        //$this->session->set_flashdata('msg',$u_name);
                        $this->session->set_userdata(array('p_name'=>$u_name,'p_id'=>$u_id));
                        $_SESSION['p_name']=$u_name;
                        $_SESSION['p_id']=$u_id;
                        $this->load->view('pharmacy/dashboard',$user);
                    }else{
                        $this->session->set_flashdata('msg','Incorrect details-l!');
                        redirect(base_url());
                    }
                }else{
                    $this->session->set_flashdata('msg','Incorrect details l');
                    redirect(base_url());
                }*/
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Pharmacist'))->result();
                //if($user==TRUE){
                foreach ($user as $r){
                    $u_name=$r->name;
                    $u_id=$r->id;
                }
                if(!empty($user)){
                    //$this->session->set_flashdata('msg',$u_name);
                    $this->session->set_userdata(array('p_name'=>$u_name,'p_id'=>$u_id));
                    $_SESSION['p_name']=$u_name;
                    $_SESSION['p_id']=$u_id;
                    $this->load->view('pharmacy/dashboard',$user);
                }else{
                    $this->session->set_flashdata('msg','Incorrect details-l!');
                    redirect(base_url());
                }
                
            }else if($user_type=="Nurse"){
                $user=$this->db->get_where('employees',array('email'=>$username,'password'=>$password,'position'=>'Nurse'))->result();
                //if($user==TRUE){
                    foreach ($user as $r){
                        $u_name=$r->name;
                        $u_id=$r->id;
                    }
                    if(!empty($user)){
                        //$this->session->set_flashdata('msg',$u_name);
                        $this->session->set_userdata(array('n_name'=>$u_name,'n_id'=>$u_id));
                        $_SESSION['n_name']=$u_name;
                        $_SESSION['n_id']=$u_id;
                        $this->load->view('nurse/dashboard',$user);
                    }else{
                        $this->session->set_flashdata('msg','Incorrect details-l!');
                        redirect(base_url());
                    }
                /*}else{
                    $this->session->set_flashdata('msg','Incorrect details l');
                    redirect(base_url());
                }*/
                
                
            }
		}else{
			$this->session->set_flashdata('msg','Fill in all the fields!');
			redirect(base_url());
		}
	}


}