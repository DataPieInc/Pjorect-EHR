<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}
	public function logout_user(){
		if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){
			$this->session->sess_destroy();
			session_destroy();
			redirect(base_url());
		}
		if(!empty($this->session->userdata('r_name'))||isset($_SESSION['r_name'])){
			$this->session->sess_destroy();
			session_destroy();
			redirect(base_url());
		}
        if(!empty($this->session->userdata('d_name'))||isset($_SESSION['d_name'])){
            $this->session->sess_destroy();
            session_destroy();
            redirect(base_url());
        }
        if(!empty($this->session->userdata('l_name'))||isset($_SESSION['l_name'])){
            $this->session->sess_destroy();
            session_destroy();
            redirect(base_url());
        }
        if(!empty($this->session->userdata('p_name'))||isset($_SESSION['p_name'])){
            $this->session->sess_destroy();
            session_destroy();
            redirect(base_url());
        }
        if(!empty($this->session->userdata('f_name'))||isset($_SESSION['f_name'])){
            $this->session->sess_destroy();
            session_destroy();
            redirect(base_url());
        }
        if(!empty($this->session->userdata('n_name'))||isset($_SESSION['n_name'])){
            $this->session->sess_destroy();
            session_destroy();
            redirect(base_url());
        }
	}
}
