<?php

/**
 * Created by PhpStorm.
 * User: Derick Oduor
 * Date: 5/27/2017
 * Time: 5:55 PM
 */
class doctor extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    public function dashboard(){
        if(!empty($this->session->userdata('d_name'))||isset($_SESSION['d_name'])){
            $this->load->view('doctor/dashboard');
        }else{
            redirect(base_url());
        }
    }
    public function view_queue(){
        $data['res']=$this->db->get_where('patient_history',array('attended_to'=>'NO'))->result();
        $this->load->view('doctor/view_queue',$data);
    }
    public function view_patient($pat_id){
        $data['res']=$this->db->get_where('patient_history',array('patient_id'=>$pat_id,'attended_to'=>'NO'))->result();
        $this->load->view('doctor/view_patient',$data);
    }
    public function send_to_lab($pat_id,$d_id){
        $tests=$this->input->post('tests');
        $additional_info=$this->input->post('additional_info');
        $this->load->model('doctor_');
        $send_to_lab=$this->doctor_->send_to_lab($pat_id,$d_id,$tests,$additional_info);
        if($send_to_lab==TRUE){
            $this->session->set_flashdata('add_msg','Patient sent to lab');
            $this->view_patient($pat_id);
        }else{
            $this->session->set_flashdata('add_msg','Patient not sent to lab');
            $this->view_patient($pat_id);
        }
    }
    public function add_patient_history($pat_id,$doctor_id){
        $complains=$this->input->post('complains');
        $vital_signs=$this->input->post('vital_signs');
        //$temperature=$this->input->post('temperature');
        $surgeries_done=$this->input->post('surgeries');
        $additional_info=$this->input->post('additional_info');

        $pat_data=array('patient_id'=>$pat_id,'complains'=>$complains,'attended_to'=>'NO','past_surgeries'=>$surgeries_done,'vital_signs'=>$vital_signs,/*'temperature'=>$temperature,*/'additional_info'=>$additional_info,'doctor_id'=>$doctor_id);
        $this->load->model('doctor_');
        $update=$this->doctor_->add_patient_history($pat_data,$pat_id);
        if($update==TRUE){
            $this->session->set_flashdata('add_msg','Patient seen');
            $this->view_patient($pat_id);
        }else{
            $this->session->set_flashdata('add_msg','Patient not seen');
            $this->view_patient($pat_id);
        }
    }
    public function fetch_history(){
        $pat_id=$this->input->post('pat_id');
        $pat_history=$this->db->get_where('patient_history',array('patient_id'=>$pat_id));
        if($pat_history->num_rows()>0){
            $patient=$this->db->get_where('patient_history',array('patient_id'=>$pat_id))->result();

            $pat_hist='<table class="table table-bordered table striped table-responsive">';
            $pat_hist.='<tr><th>Visit date</th><th>Admission Type</th><th>Cause of Visit</th><th>Complains</th><th>Diagnosis</th><th>Treatment</th><th>Additional Information</th></tr>';
            foreach ($patient as $p){
                $pat_hist.='<tr><td>'.$p->visit_date.'</td><td>'.$p->admission_type.'</td><td>'.$p->visit_type.'</td><td>'.$p->complains.'</td><td>'.$p->diagnosis.'</td><td>'.$p->treatment.'</td><td>'.$p->additional_info.'</td></tr>';
            }
            $pat_hist.='</table>';
            echo $pat_hist;
        }else{
            echo'<div class="container">The are history records for this patient.</div>';
        }

    }
    public function inpatient($pat_id){
        //$patient=$this->db->get_where('patient_history',array('patient_id'=>$pat_id,'attended_to'=>'NO'));
        //if($patient->num_rows()==0){
            $patient['res']=$this->db->get_where('patient_history',array('patient_id'=>$pat_id,'attended_to'=>'NO'))->result();
        //}
        $this->load->view('doctor/admit_inpatient',$patient);
    }
    public function admit_inpatient($pat_id){
        $pat_data=array('admission_type'=>'INPATIENT');
        $this->db->set($pat_data);
        $this->db->where(array('patient_id'=>$pat_id,'attended_to'=>'NO'));
        $admit=$this->db->update('patient_history',$pat_data);
        if($admit){
            $this->session->set_flashdata('admit_inpatient','Patient admitted to inpatient!');
            $this->view_patient($pat_id);
        }else{
            $this->session->set_flashdata('admit_inpatient','Failed to admit to inpatient!');
            $this->view_patient($pat_id);
        }
    }
    public function diagnosis(){
        $patient_id=$this->input->post('patient_id');
        $doctor_id=$this->input->post('doctor_id');
        $diagnosis=$this->input->post('diagnosis');
        $update=array('diagnosis'=>$diagnosis);
        $this->load->model('doctor_');
        $set_diagnosis=$this->doctor_->diagnosis($update,$patient_id);
        if($set_diagnosis==TRUE){
            $this->session->set_flashdata('Diag_info','Diagnosis saved!');
            $this->view_patient($patient_id);
        }else{
            $this->session->set_flashdata('Diag_info','Diagnosis not saved!');
            $this->view_patient($patient_id);
        }
    }
    public function get_lab_results(){
        $doctor_id=$this->input->post('doctor_id');
        $patient_id=$this->input->post('patient_id');
        $data=$this->db->get_where('lab_reports',array('doctor_id'=>$doctor_id,'patient_id'=>$patient_id,'seen_by_doctor'=>'NO'));
        $count=$data->num_rows();
        if($count>0){
            $data=$this->db->get_where('lab_reports',array('doctor_id'=>$doctor_id,'patient_id'=>$patient_id,'seen_by_doctor'=>'NO'))->result();
            foreach ($data as $d){
                $tests=$d->tests;
                $lab_res=$d->lab_results;
                $results='<div class="container"><b><span style="font-size:14;color:blue;">'.$tests.'</span></b<br/><div>'.$lab_res.'</div></div>';
                $data=array('lab_results'=>$results,'count'=>$count);
            }
            echo json_encode($data);
            
        }else{
            $data=array('count'=>$count);
            echo json_encode($data);
        }
        
        //echo 'Received';
    }
    public function treatment(){
        $patient_id=$this->input->post("patient_id");
        $doctor_id=$this->input->post("doctor_id");
        $treatment=$this->input->post("treatment");
        //echo $patient_id." ".$doctor_id." ".$treatment;
        $update=array('treatment'=>$treatment);
        $this->load->model("doctor_");
        $set_treatment=$this->doctor_->treatment($update,$patient_id);
        if($set_treatment==TRUE){
            $this->session->set_flashdata("treatment",$patient_id." given treatment");
            $pat_name=$this->db->get_where('patient_history',array('patient_id'=>$patient_id))->result();
            foreach ($pat_name as $p){
                $patient_name=$p->name;
            }
            $prescription=array('medication'=>$treatment,'date'=>gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*+3),'patient_name'=>$patient_name,'doctor_id'=>$doctor_id,'patient_id'=>$patient_id);
            $set_prescription=$this->doctor_->prescription($prescription);
            $this->view_patient($patient_id);
        }else{
            $this->session->set_flashdata("treatment",$patient_id." not given treatment");
            $this->view_patient($patient_id);
        }
    }
    public function discharge(){
        if(isset($_POST['discharge'])){
            $patient_id=$this->input->post('patient_id');
            $doctor_id=$this->input->post('doctor_id');
            $update=array('attended_to'=>'YES','date_discharged'=>gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*+3));
            $this->load->model('doctor_');
            $dis=$this->doctor_->discharge($update,$patient_id);
            if($dis==TRUE){
                $this->session->set_flashdata('discharge','Patient discharged');
                $this->served_patients();
            }else{
                $this->session->set_flashdata('discharge','Patient not discharged');
                $this->view_patient($patient_id);
            }
        }
    }
    public function served_patients(){
        $data['res']=$this->db->get_where('patient_history',array('attended_to'=>'YES'))->result();
        $this->load->view('doctor/served_patients',$data);
    }
}