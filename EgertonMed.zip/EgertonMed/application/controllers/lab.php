<?php

/**
 * Created by PhpStorm.
 * User: Derick Oduor
 * Date: 5/28/2017
 * Time: 5:43 PM
 */
class lab extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }
    public function dashboard(){
        $this->load->view('lab/dashboard');
    }
    public function new_lab_exams(){
        $data['res']=$this->db->get('lab_exams')->result();
        $this->load->view('lab/new_lab_exams',$data);
    }
    public function view_lab_exam($pat_id){
        $exam['res']=$this->db->get_where('lab_exams',array('patient_id'=>$pat_id))->result();
        $this->load->view('lab/view_lab_exam',$exam);
    }
    public function lab_exam_seen(){
        if(isset($_POST['lab_test_seen'])&&($_POST['lab_test_seen'])){
            $patient_id=$this->input->post('patient_id');
            $lab_update=array('patient_id'=>$patient_id,'status'=>'processing');
            $this->load->model('Lab_');
            $lab_updated=$this->Lab_->lab_exam_seen($lab_update);
            if($lab_updated==TRUE){
                $this->session->set_flashdata('lab_msg','Lab exam being processed');
                $this->view_lab_exam($patient_id);
            }else{
                $this->session->set_flashdata('lab_msg','Failed to queue exam to processing');
                
            }
        }else{
            $this->view_lab_exam($patient_id);
        }
    }
    public function lab_results($test){
        $patient_id=$this->input->post('patient_id');
        /*$test=$this->input->post('test');*/
        $result=$this->input->post('results');
        $lab_exam_id=$this->input->post('exam_id');
        $lab_staff_id=$this->input->post('lab_staff_id');
        $doctor_id=$this->input->post('doctor_id');
        $additional_info=$this->input->post('add_info');
        $date=gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*+3);
        
        $res=$this->db->get_where('lab_exams',array('patient_id'=>$patient_id,'status'=>'Processing'))->result();
        foreach ($res as $r){
            $pat_name=$r->patient_name;
        }
        
        $update_history=array('lab_exam'=>$test,'lab_results'=>$result);
        
        $lab_result_data=array('patient_id'=>$patient_id,'tests'=>$test,'lab_results'=>$result,'doctor_id'=>$doctor_id,
            'lab_official_id'=>$lab_staff_id,'additional_info'=>$additional_info,'date'=>$date/*,'patient_name'=>$pat_name*/);
        $this->load->model('Lab_');
        $results_entered=$this->Lab_->lab_results($lab_result_data);
        if($results_entered==TRUE){
            $update_lab=$this->Lab_->update_lab_table($patient_id);
            if($update_lab==TRUE){
                $this->load->model('Lab_');
                $history=$this->Lab_->update_pat_history($update_history,$patient_id);
                if($history==TRUE){
                    $this->session->set_flashdata('lab_msg','Lab results sent!');
                    $this->view_lab_exam($patient_id);
                }else{
                    $this->session->set_flashdata('lab_msg','Patient history not updated!');
                    $this->view_lab_exam($patient_id);
                }
            }else{
                $this->session->set_flashdata('lab_msg','Lab table not updated!');
                $this->view_lab_exam($patient_id);
            }
        }else{
            $this->session->set_flashdata('lab_msg','Lab results not sent!');
            $this->view_lab_exam($patient_id);
        }
    }
    public function get_results(){
        if(isset($_POST['patient_id'])){
            $patient_id=$_POST['patient_id'];
            $results=$this->db->get_where('lab_reports',array('patient_id'=>$patient_id));
            if($results->num_rows()>0){
                $res=$this->db->get_where('lab_reports',array('patient_id'=>$patient_id))->result();
                $t='<table class="table table-striped table-bordered table-hover table responsive">
                    <tr><th>Test</th><th>Additional Info.</th><th>Results</th><th>Date</th><th>Done By</th></tr>';
                foreach ($res as $r){
                    $t.='<tr><td>'.$r->tests.'</td><td>'.$r->additional_info.'</td><td>'.$r->lab_results.'</td><td>'.$r->date.'</td><td>'.$this->session->userdata('l_name').'</td></tr>';
                }
                $t.='</table>';
                echo $t;
            }else{
                echo'<div class="container"style="color:red;">There are no lab records for this patient.</div>';
            }
        }
    }
    public function lab_reports(){
        $reports['res']=$this->db->get('lab_reports')->result();
        $this->load->view('lab/lab_reports',$reports);
    }
}