<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller{
	public function __construct(){
		parent::__construct();
                $this->load->helper('form');
		$this->load->library('form_validation');
                $this->load->library('session');
	}
	public function employees(){
		$data['rows']=$this->db->get('employees')->result();
		$emp=$this->db->get('employees');
		if($emp->num_rows()>0){
			$this->session->set_flashdata('msg','employees');
			$this->load->view('admin/employees',$data);
		}else{
			$this->session->set_flashdata('msg','No employees');
			$this->load->view('admin/employees');
		}
		
	}
	public function dashboard(){
		if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){
			$this->load->view('admin/dashboard');
		}else{
			redirect(base_url());
		}
	}
	public function new_employee(){
		$this->load->view('admin/new_employee');
	}
	public function add_employee(){
            $this->load->library('form_validation');
		//$this->session->unset_flashdata('err_msg');
            $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
// Validation For Name Field
            $this->form_validation->set_rules('name', 'Username', 'required|min_length[3]|max_length[40]');
// Validation For Email Field
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
// Validation For Contact Field
            $this->form_validation->set_rules('phone', 'Contact No.', 'required|regex_match[/^[0-9]{10}$/]');
// Validation For Address Field
            $this->form_validation->set_rules('h_address', 'Address', 'required|min_length[5]|max_length[50]');
            /*$this->form_validation->set_rules('password', 'Password', 'trim|required|matches[cpassword]|md5');
            $this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required');*/
            if($this->form_validation->run()==FALSE){
        	$this->session->set_flashdata('err_msg','Invalid entry(s)! Please fill in again.');
        	$this->load->view('admin/new_employee');
            }else if($this->form_validation->run()==TRUE){
                $name=$this->input->post('name');
                $phone=$this->input->post('phone');
                $email=$this->input->post('email');
                $h_address=  $this->input->post('h_address');
                $kin_name=$this->input->post('kin_name');
                $kin_no=$this->input->post('kin_no');
                $dob=  $this->input->post('dob');
                $dor=  $this->input->post('dor');
                $dept=  $this->input->post('dept');
                $pos=  $this->input->post('pos');
                $gender=$this->input->post('gender');
                $emp_data=array('name'=>$name,'phone'=>$phone,'email'=>$email,'h_address'=>$h_address,'kin_name'=>$kin_name,'kin_phone'=>$kin_no,
                    'date_of_birth'=>$dob,'date_of_recr'=>$dor,'department'=>$dept,'position'=>$pos,'password'=>$email,'gender'=>$gender);
                
                $this->load->model('admin_');
                $emp_added=$this->admin_->add_emp($emp_data);
                if($emp_added==TRUE){
                    $this->session->set_flashdata('err_msg','User added.');
                    $this->employees();
                }else{
                    $this->session->set_flashdata('err_msg','User exists.');
        	$this->load->view('admin/new_employee');
                }
        	
            }
	}
        public function sus_employee($emp_id,$status){
            if($status=="Suspend"){
                //$emp_id=$this->input->get('id');
                $emp_data['row']=$this->db->get_where('employees',array('id'=>$emp_id))->result();
                //$this->session->set_flashdata('t',$emp_id);
                $this->load->view('admin/sus_employee',$emp_data);
            }else if($status=="Unsuspend"){
                //$emp_id=$this->input->get('id');
                $emp_data['row']=$this->db->get_where('employees',array('id'=>$emp_id))->result();
                //$this->session->set_flashdata('t',$emp_id);
                $this->load->view('admin/unsus_employee',$emp_data);
            }
            
        }
        public function del_employee($emp_id){
            $emp_data['row']=$this->db->get_where('employees',array('id'=>$emp_id))->result();
                //$this->session->set_flashdata('t',$emp_id);
                $this->load->view('admin/del_employee',$emp_data);
            
        }
        public function suspend($emp_id){
            $this->load->model('admin_');
            $this->admin_->suspend($emp_id);
            //$this->employees();
            $data['rows']=$this->db->get('employees')->result();
		$emp=$this->db->get('employees');
		if($emp->num_rows()>0){
			$this->session->set_flashdata('msg','employees');
			$this->load->view('admin/employees',$data);
		}else{
			$this->session->set_flashdata('msg','No employees');
			$this->load->view('admin/employees');
		}
        }
        public function unsuspend($emp_id){
            $this->load->model('admin_');
            $this->admin_->unsuspend($emp_id);
            //$this->employees();
            $data['rows']=$this->db->get('employees')->result();
		$emp=$this->db->get('employees');
		if($emp->num_rows()>0){
			$this->session->set_flashdata('msg','employees');
			$this->load->view('admin/employees',$data);
		}else{
			$this->session->set_flashdata('msg','No employees');
			$this->load->view('admin/employees');
		}
        }
        public function delete_emp($emp_id){
            $this->load->model('admin_');
            $this->admin_->delete_emp($emp_id);
            //$this->employees();
            $data['rows']=$this->db->get('employees')->result();
		$emp=$this->db->get('employees');
		if($emp->num_rows()>0){
			$this->session->set_flashdata('msg','employees');
			$this->load->view('admin/employees',$data);
		}else{
			$this->session->set_flashdata('msg','No employees');
			$this->load->view('admin/employees');
		}
        }
        public function search_emp(){
            $key=$this->input->post('emp_key');
            //echo 'Received';
            $this->load->model('admin_');
            $query=$this->admin_->search_emp($key);
            $data['res']=array();
            if(!empty($query)){
                $t="<table class='table table-striped table-responsive table-bordered'>";
                foreach($query as $d){
                    
                    $t.="<tr><td>".$d->id."</td><td>".$d->name."</td></tr>";
                }
                $t.="</table>";
                echo'Received '.$t;
            }else{
                echo'Not';
            }
        }
}