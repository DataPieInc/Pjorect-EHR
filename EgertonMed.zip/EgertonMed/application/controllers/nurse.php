<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nurse extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
    }
    public function dashboard(){
        $this->load->view('nurse/dashboard');
    }
    public function view_queue(){
        $data['res']=$this->db->get_where('patient_history',array('nurse_id'=>0))->result();
        $this->load->view('nurse/view_queue',$data);
    }
    public function view_patient($patient_id){
        $data['res']=$this->db->get_where('patient_history',array('patient_id'=>$patient_id,'attended_to'=>'NO'))->result();
        $this->load->view('nurse/view_patient',$data);
    }
    public function save_measurements(){
        //match_name=/^[a-zA-Z0-9 ]*$/,m=/[0-9]/,r_email=/([\w\-]+\@[\w\-]+\.[\w\-]+)/,reg_cor=/([a-zA-Z0-9]+\/[0-9]+\/[0-9]+)/;
        $nurse_id=$this->input->post('nurse_id');
        $patient_id=$this->input->post('patient_id');
        $temperature=$this->input->post('temperature');
        $height=$this->input->post('height');
        $weight=$this->input->post('weight');
        $blood_pressure=$this->input->post('blood_pressure');
        $heart_rate=$this->input->post('heart_rate');
        $this->load->model('nurse_');
        if(!(is_numeric($temperature))&& $temperature!='N/A'){
            if($temperature!='N/A'){
                $this->session->set_flashdata('nurse_data','Invalid temperature');
                $this->view_patient($patient_id);
            }
        }
        if(!(is_numeric($weight))&&$weight!='N/A'){
            if($weight!='N/A'){
                $this->session->set_flashdata('nurse_data','Invalid weight');
                $this->view_patient($patient_id);
            }
        }
        if(!(is_numeric($height))&&$height!='N/A'){
            if($height!='N/A'){
                $this->session->set_flashdata('nurse_data','Invalid height');
                $this->view_patient($patient_id);
            }
        }
        if(!(is_numeric($blood_pressure))&& $blood_pressure!='N/A'){
            if($blood_pressure!='N/A'){
                $this->session->set_flashdata('nurse_data','Invalid entry for blood pressure');
                $this->view_patient($patient_id);
            }
        }
        if(!(is_numeric($heart_rate))&& $heart_rate!='N/A'){
            if($heart_rate!='N/A'){
                $this->session->set_flashdata('nurse_data','Invalid entry for heart rate');
                $this->view_patient($patient_id);
            }
        }
        /*if(is_numeric($temperature)){
            if($temperature<0){
                $this->session->set_flashdata('nurse_data','Invalid temperature');
                $this->view_patient($patient_id);
                exit();
            }
        }elseif (($temperature[0]=='N'||$temperature[0]=='n')&&($temperature[2]=='N'||$temperature[2]=='n')){
            if(!preg_match('/([a-zA-Z]+\/[a-zA-Z])/', $temperature)){
                $this->session->set_flashdata('nurse_data','Invalid temperature');
                $this->view_patient($patient_id);
                exit();
            }
        }else{
            $this->session->set_flashdata('nurse_data','Invalid temperature');
            $this->view_patient($patient_id);
            exit();
        }
        if(is_numeric($weight)){
            if($weight<0){
                $this->session->set_flashdata('nurse_data','Invalid temperature');
                $this->view_patient($patient_id);
                exit();
            }
        }elseif (($weight[0]=='N'||$weight[0]=='n')&&($weight[2]=='N'||$weight[2]=='n')){
            if(!preg_match('/([a-zA-Z]+\/[a-zA-Z])/',$weight)){
                $this->session->set_flashdata('nurse_data','Invalid temperature');
                $this->view_patient($patient_id);
                exit();
           }
        }else{
            $this->session->set_flashdata('nurse_data','Invalid temperature');
            $this->view_patient($patient_id);
            exit();
        }
        if(is_numeric($height)){
            if($height<0){
                $this->session->set_flashdata('nurse_data','Invalid height');
                $this->view_patient($patient_id);
                exit();
            }
        }elseif (($height[0]=='N'||$height[0]=='n')&&($height[2]=='N'||$height[2]=='n')){
            if(!preg_match('/([a-zA-Z]+\/[a-zA-Z])/',$height)){
                $this->session->set_flashdata('nurse_data','Invalid Height');
                $this->view_patient($patient_id);
                exit();
            }
        }else{
            $this->session->set_flashdata('nurse_data','Invalid Height');
            $this->view_patient($patient_id);
            exit();
        }
        if(preg_match('/([a-zA-Z0-9])/',$blood_pressure)){
            if($blood_pressure<0){
                $this->session->set_flashdata('nurse_data','Invalid entry for blood pressure!');
                $this->view_patient($patient_id);
                exit();
            }
        }elseif (($blood_pressure[0]=='N'||$blood_pressure[0]=='n')&&($blood_pressure[2]=='N'||$blood_pressure[2]=='n')){
            if(!preg_match('/([a-zA-Z]+\/[a-zA-Z])/',$blood_pressure)){
                $this->session->set_flashdata('nurse_data','Invalid entry for blood pressure!');
                $this->view_patient($patient_id);
                exit();
            }
        }else{
            $this->session->set_flashdata('nurse_data','Invalid entry for blood pressure!');
            $this->view_patient($patient_id);
            exit();
        }
        if(preg_match('/([a-zA-Z0-9])/',$heart_rate)){
            if($heart_rate<0){
                $this->session->set_flashdata('nurse_data','Invalid entry for heart rate!');
                $this->view_patient($patient_id);
                exit();
            }
        }elseif (($heart_rate[0]=='N'||$heart_rate[0]=='n')&&($heart_rate[2]=='N'||$heart_rate[2]=='n')){
            if(!preg_match('/([a-zA-Z]+\/[a-zA-Z])/',$blood_pressure)){
                $this->session->set_flashdata('nurse_data','Invalid entry for heart rate!');
                $this->view_patient($patient_id);
                exit();
            }
        }else{
            $this->session->set_flashdata('nurse_data','Invalid entry for heart rate!');
            $this->view_patient($patient_id);
            exit();
        }*/
        $update=array('nurse_id'=>$nurse_id,'temperature'=>$temperature,'height'=>$height,'weight'=>$weight,'heart_rate'=>$heart_rate,'blood_pressure'=>$blood_pressure);
        $result=$this->nurse_->save_measurements($update,$patient_id);
        if($result==TRUE){
            $this->session->set_flashdata('nurse_data','Records updated');
            $this->view_queue();
        }else{
            $this->session->set_flashdata('nurse_data','Records update failed');
            $this->view_patient($patient_id);
        }
    }
    /*public function remaining_queue(){
        $data['res']=$this->db->get_where('patient_history',array('nurse_id'=>!0))->result();
        $this->load->view('nurse/view_queue',$data);
    }*/
}