<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('d_name'))||isset($_SESSION['d_name'])){

    foreach ($res as $r){
        $patient_name=$r->name;
        $patient_id=$r->patient_id;
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Medical Department</title>
        <script type="text/javascript"src></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        <link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
        <link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modal.js"></script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
        <script src="http://localhost/egertonmed/index.php/js/jquery.js"></script>
        <script src="../<?php base_url('index.php')?>../js/script.js"></script>
    </head>
    <body>
    <?php
//    echo $this->session->userdata('d_name');
    ?>
    <div class="container">
        <header role="banner" class="navbar navbar-fixed-top navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                </div>
                <div class="navbar-inverse side-collapse in">
                    <nav role="navigation" class="navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo base_url('index.php').'/doctor/dashboard'?>">Home</a></li>
                            <li><a href="<?php echo base_url('index.php').'/doctor/view_queue'?>">View queue</a></li>
                            <li><a href="<?php echo base_url('index.php').'/doctor/served_patients'?>">View Served Patients</a></li>
                            <li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                            <li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('d_name');?></a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    </div>
    <br/><br/><br/>
    <div class="container content">
        <?php
        if(!empty($res)){?>
        <ul id="menu">
            <li><a href="#view_patient"id="v_p">View Patient</a></li>
            <li><a href="#patient_history"id="p_h">Patient History</a></li>
            <li><a href="#lab_results"id="l_r"class="dropdown-toggle" data-toggle="dropdown">&nbsp;Lab Results<span class="badge"id="count"></span></a><ul class="dropdown-menu"></ul></li>
            <li><a href="#diagnosis"id="d">Diagnosis</a></li>
            <li><a href="#prescription"id="pres">Prescription</a></li>
            <li><a href="#discharge"id="d_c">Discharge</a></li>
        </ul>
        <div class="container"id="view_patient">
            <div>
            <?php
            echo $this->session->flashdata('add_msg').'<br/>';
            echo $this->session->flashdata('Diag_info');

                foreach ($res as $r){
                    $patient_name=$r->name;
                    $patient_id=$r->patient_id;
                    $admission_type=$r->admission_type;
                    $status=$r->attended_to;
                    $temperature=$r->temperature;
                    $weight=$r->weight;
                    $height=$r->height;
                    $blood_pressure=$r->blood_pressure;
                    $heart_rate=$r->heart_rate;
                    echo'<h1>'.$r->name.' '.$r->patient_id.'</h1><br/><span><b>Cause of visit</b>&nbsp;: '.$r->visit_type.'</span>';
                }


            ?>
                <div class="container"data-patient_id="<?php echo $patient_id?>"id="pat_">
                    <?php
                    /*if($admission_type=="OUTPATIENT"){
                        echo '<a href="http://localhost/egertonmed/index.php/doctor/inpatient/'.$patient_id.'"class="btn btn-warning">Admit to inpatient</a><br/>';
                    }else if($admission_type=="INPATIENT"){
                        echo '<a href=""class="btn btn-danger">Patient Admitted to Inpatient</a><br/>';
                    }*/
                    ?>
                    <form action="http://localhost/egertonmed/index.php/doctor/add_patient_history/<?php echo $patient_id.'/'.$this->session->userdata('d_id')?>"method="post">
                    	<div class="container"style="border:1px solid black;padding:5px;margin-bottom:7px;"><span><b>Body Temperature:</b></span><span style="margin-left:25px"><?php echo $temperature;?>degree celcius</span></div>
                    	<div class="container"style="border:1px solid black;padding:5px;margin-bottom:7px;"><span><b>Heart Rate:</b></span><span style="margin-left:25px"><?php echo $heart_rate;?>beats/min</span></div>
                    	<div class="container"style="border:1px solid black;padding:5px;margin-bottom:7px;"><span><b>Blood Pressure:</b></span><span style="margin-left:25px"><?php echo $blood_pressure;?></span></div>
                    	<div class="container"style="border:1px solid black;padding:5px;margin-bottom:7px;"><span><b>Weight:</b></span><span style="margin-left:25px"><?php echo $weight;?>kg</span></div>
                    	<div class="container"style="border:1px solid black;padding:5px;margin-bottom:7px;"><span><b>Height:</b></span><span style="margin-left:25px"><?php echo $height;?>meters</span></div>
                        <div class="form-group">
                            <label class="control-label">Comlpains</label>
                            <textarea name="complains"class="form-control"rows="5"required></textarea>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Vital Signs</label>
                            <textarea name="vital_signs"class="form-control"rows="5"required></textarea>
                        </div>
                        <!--<div class="form-group">
                            <label class="control-label">Temperature</label>
                            <input type="text"name="temperature"class="form-control"required/>
                        </div>-->
                        <div class="button-popup">
							<a href="#"id="button-popup"class="btn btn-warning">Send to lab</a>
						</div>
                        <div class="form-group">
                            <label class="control-label">Have you had any previous surgeries?</label>
                            <select class="form-control"name="surgeries"required>
                                <option></option>
                                <option>Yes</option>
                                <option>No</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Additional Information</label>
                            <textarea class="form-control"name="additional_info"rows="5"required></textarea>
                        </div>
                        <button class="btn btn-primary"type="submit">Submit</button>
                    </form>
                </div>

        </div>
        <div class="window-popup">
			<div class="wp-content">
				<h1>Lab form for <?php echo $patient_name.'-'.$patient_id;?></h1>
				<form action="http://localhost/egertonmed/index.php/doctor/send_to_lab/<?php echo $patient_id.'/'.$this->session->userdata('d_id');?>"method="post">
                    <div class="form-group">
                       <label class="control-label">Tests</label>
                       <textarea class="form-control"name="tests"rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Additional Information</label>
                        <textarea class="form-control"name="additional_info"rows="5"></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary"type="submit">Send</button>
                        <button class="btn btn-warning"id="button-popup-close">Cancel</button>
                    </div>
                </form>
			</div>
		</div>
    </div>
    <div class="container"id="patient_history"></div>
            <div class="container"id="lab_results"></div>
            <div class="container"id="diagnosis">
            	<form action="http://localhost/egertonmed/index.php/doctor/diagnosis"method="post">
            		<div class="form-group">
            			<label class="control-label">Patient Suffering from</label>
            			<textarea rows="5"name="diagnosis"class="form-control"placeholder="Diagnosis"required></textarea>
            		</div>
            		<input type="hidden"name="patient_id"value="<?php echo $patient_id?>"/>
            		<input type="hidden"name="doctor_id"value="<?php echo $this->session->userdata('d_id')?>"/>
            		<div class="form-group">
            			<button type="submit"class="btn btn-primary">Submit</button>
            		</div>
            	</form>
            </div>
            
            <div class="container"id="discharge">
            	<form action="http://localhost/egertonmed/index.php/doctor/discharge"method="post">
            		<?php echo $this->session->flashdata('discharge');?>
            		<input type="hidden"name="patient_id"value=<?php echo $patient_id?>>
            		<input type="hidden"name="doctor_id"value=<?php echo $this->session->userdata('d_id')?>>
            		<input type="checkbox"name="discharge"class="checkbox"/><span style="color:red"required>By checking this box you confirm that the patient is clear for discharge!</span>
            		<br/><button type="submit"class="btn btn-warning">Discharge Patient</button>
            	</form>
            </div>
            <div class="container"id="prescription">
            	<div class="container">
            	<?php 
                    echo "<span style='color:red'>".$this->session->flashdata("treatment")."</span>";
                ?>
            	</div>
            	<form action="http://localhost/egertonmed/index.php/doctor/treatment"method="post">
            		<div class="form-group">
            			<label class="control-label"for="treatment">Treatment</label>
            			<input type="hidden"name="patient_id"value="<?php echo $patient_id?>"/>
      		      		<input type="hidden"name="doctor_id"value="<?php echo $this->session->userdata('d_id')?>"/>
            			<textarea class="form-control"name="treatment"rows="5"placeholder="Treatment"required></textarea>
            		</div>
            		<div class="form-group">
            			<button type="submit"class="btn btn-primary">Submit</button>
            		</div>
            	</form>
            </div>
        <?php
        }
        ?>
    </div>
    </body>
    <?php 
        if(!empty($res)){
            foreach ($res as $r){
                $patient_name=$r->name;
                $patient_id=$r->patient_id;
            }
        
    ?>
<script type="text/javascript">
    $(function(){
        //alert('ready');
        $('#discharge').hide();
        $('#prescription').hide();
        $('#view_patient').show();
        $('#diagnosis').hide();
        $('#patient_history').hide();
        $('#lab_results').hide();
        $('#v_p').click(function(){
            $('#view_patient').show();
            $('#patient_history').hide();
            $('#lab_results').hide();
            $('#diagnosis').hide();
            $('#treatment').hide();
            $('#prescription').hide();
            $('#discharge').hide();
        });
        $('#p_h').click(function(){
            $('#view_patient').hide();
            $('#patient_history').show();
            $('#lab_results').hide();
            $('#diagnosis').hide();
            $('#treatment').hide();
            $('#prescription').hide();
            $('#discharge').hide();
            var pat_id=$('#pat_').data('patient_id');
            $.ajax({
                url:'http://localhost/egertonmed/index.php/doctor/fetch_history',
                type:'POST',
                data:{'pat_id':pat_id},
                success:function(msg){
                    //alert(msg);
                    $('#patient_history').html(msg);
                },
                error:function () {
                    alert('Something went wrong!');
                }
            });
        });
        $('#l_r').click(function() {
            $('#view_patient').hide();
            $('#patient_history').hide();
            $('#lab_results').show();
            $('#diagnosis').hide();
            $('#treatment').hide();
            $('#prescription').hide();
            $('#discharge').hide();
        });
        $('#d').click(function() {
            $('#view_patient').hide();
            $('#patient_history').hide();
            $('#lab_results').hide();
            $('#diagnosis').show();
            $('#treatment').hide();
            $('#prescription').hide();
            $('#discharge').hide();
        });
        $('#pres').click(function() {
            $('#view_patient').hide();
            $('#patient_history').hide();
            $('#lab_results').hide();
            $('#diagnosis').hide();
            $('#prescription').show();
            $('#discharge').hide();
        });
        $('#d_c').click(function() {
            $('#view_patient').hide();
            $('#patient_history').hide();
            $('#lab_results').hide();
            $('#diagnosis').hide();
            $('#prescription').hide();
            $('#discharge').show();
        });
        $('#button-popup').click(function(){
			$('.window-popup').fadeIn('slow');
		});
		$('#button-popup-close').click(function(){
			$('.window-popup').fadeOut("slow");
		});
		function get_lab_results(){
			var doctor_id=<?php echo $this->session->userdata('d_id');?>;
			var patient_id=<?php echo $patient_id;?>;
			//alert(doctor_id+' '+patient_id);
			$.ajax({
				url:'http://localhost/egertonmed/index.php/doctor/get_lab_results',
				type:'POST',
				data:{'doctor_id':doctor_id,'patient_id':patient_id},
				dataType:'json',
				success:function(msg){
					//alert(msg.count+' '+msg.lab_results);
					if(msg.count!=0){
						$('#count').html(msg.count);
						$('#lab_results').html(msg.lab_results);
					}else{
						$('#count').html('0');
						$('#lab_results').html('<div>No lab results!</div>');
					}
				},
				error:function(){
					alert('Something went wrong!');
				}
			});
		}
		//get_lab_results();
		setInterval(get_lab_results,5000);
    });
</script>
    </html>
<?php
        }
}else{
    redirect(base_url());
}
?>
<style>
    #menu{
        list-style: none;
        background: #5bc0de;
        padding: 5px;
    }
    #menu li{
        display: inline;
        padding: 5px;
    }
    #menu li a{
        padding: 5px;
        color: #ffffff;
        text-decoration: none;
    }
    #menu li a:hover{
        background: #2e8ece;
    }
.window-popup{
	width:100%;
	height:100%;
	position:fixed;
	z-index:10;
	background:rgba(0,0,0,0.7);
	top:0;
	left:0;
	display:none;
}
.show_popup{
	display:block;
}
.wp-content{
	width:550px;
	height:450px;
	background:#ffffff;
	border-radius:3px;
	position:absolute;
	left:30%;
	top:25%;
	padding:7px;
}
.wp-content a{
	padding:10px;
	background:#3498db;
	color:#ffffff;
	text-decoration:none;
	position:absolute;
	right:20px;
	bottom:20px;
	border-radius:5px;
}
</style>