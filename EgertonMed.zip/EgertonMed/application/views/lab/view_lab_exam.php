<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('l_name'))||isset($_SESSION['l_name'])){


    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Medical Department</title>
        <script type="text/javascript"src></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
        <link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
        <link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
        <script src="../<?php base_url('index.php')?>../js/script.js"></script>
    </head>
    <body>
    <?php

    echo $this->session->userdata('d_name');
    ?>
    <div class="container">
        <header role="banner" class="navbar navbar-fixed-top navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                </div>
                <div class="navbar-inverse side-collapse in">
                    <nav role="navigation" class="navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo base_url('index.php').'/lab/dashboard'?>">Home</a></li>
                            <li><a href="<?php echo base_url('index.php').'/lab/new_lab_exams'?>">Pending lab exams</a></li>
                            <li><a href="<?php echo base_url('index.php').'/lab/lab_reports'?>">Lab reports</a></li>
                            <li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                            <li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('l_name');?></a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    </div>
    <br/><br/>
    <div class="container content">
        <div class="container"id="pending_exams">
            <?php
            if(!empty($res)){
                foreach($res as $r){
                    $patient_id=$r->patient_id;
                    $pat_name=$r->patient_name;
                    $doctor_id=$r->doctor_id;
                    $doc_name=$r->doctor_name;
                    $tests=$r->tests;
                    $additional_info=$r->additional_info;
                    $status=$r->status;
                    $lab_exam_id=$r->id;
                }
            ?>
            	<div class="container">
            	<br/><br/>
            		<ul id="lab_menu">
            			<li><a href="#lab_test"id="t">Lab test</a></li>
            			<li><a href="#fill_results"id="f_r">Fill Results</a></li>
            			<li><a href="#lab_results"id="v_r">View Results</a></li>
            		</ul>
            	</div>
                <div class="container"id="lab_test">
                    <h1><?php echo $pat_name.'-'.$patient_id?></h1>
                    <div class="container">
                        Sent by<?php echo ' '.$doc_name.'-'.$doctor_id;?>
                    </div>
                    <div class="container input-group">
                    <div class="container"style="color:red;"><?php 
                    if($status=='Procession'){
                        echo'This exam is being processed.';
                    }elseif($status=='Pending'){
                        echo'This exam is yet to be processed.';
                    }elseif($status=='Done'){
                        echo'This exam is already done and results are available.';
                    }
                    echo '<br/>'.$this->session->flashdata('lab_msg');?></div>
                    <div class="row"id="test">
                        <div class="col-xs-2"><b>Test</b></div>
                        <div class="col-xs-10"><?php echo $tests?></div>
                    </div>
                    <div class="row"id="add_info">
                        <div class="col-xs-2"><b>Additional Information</b></div>
                        <div class="col-xs-10"><?php echo $additional_info?></div>
                    </div>
                    <div class="container">
                    <?php 
                    if($status=="Processing"){
                    ?>	
                    <form action=""method="">
                    		<div class="form-group">
                    			<input type="checkbox" name="lab_test_seen" value="lab_test_seen"checked/>&nbsp;Seen<br/>
                    		</div>
                    		<button class="btn btn-info">Results are still pending</button>
                    	</form>
                    <?php 
                        }elseif($status=='Done'){
                    ?>
                    <form action=""method="">
                    		<div class="form-group">
                    			<b>Status</b>&nbsp;<input type="checkbox" name="lab_test_seen" value="lab_test_seen"checked/>&nbsp;Seen<br/>
                    		</div>
                    		<button class="btn btn-danger">Results are ready</button>
                    	</form>
                    <?php
                        }elseif($status=='Pending'){
                    ?>
                    	<form action="http://localhost/egertonmed/index.php/lab/lab_exam_seen"method="post">
                    		<div class="form-group">
                    			<input type="checkbox" name="lab_test_seen" value="lab_test_seen" />&nbsp;Mark as seen<br/>
                    		</div>
                    		<input type="hidden"name="patient_id"value="<?php echo $patient_id?>"/>
                    		<div class="form-group">
                    			<button type="submit"class="btn btn-primary">Start Processing</button>
                    		</div>
                    	</form>
                    <?php 
                        }
                    ?>        
                    </div>
                </div>
                <?php
            }else{
                echo'<div class="container"style="color:red;">No tests found for this patient.</div>';
            }

            ?>
        </div>
        <div class="container"id="fill_results">
        	<form action="http://localhost/egertonmed/index.php/lab/lab_results/<?php echo $tests;?>"method="post">
                <div class="row"id="test">
                	<div class="col-xs-2"><b>Test</b></div>
                	<div class="col-xs-10"><?php echo $tests;?></div>
                </div>
                <input type="hidden"name="patient_id"value="<?php echo $patient_id;?>"/>
                <input type="hidden"name="tests"value="<?php //echo $tests;?>"/>
                <input type="hidden"name="exam_id"value="<?php echo $lab_exam_id;?>"/>
                <input type="hidden"name="lab_staff_id"value="<?php echo $this->session->userdata('l_id');?>"/>
                <input type="hidden"name="doctor_id"value="<?php echo $doctor_id;?>"/>
                <div class="form-group">
                	<label class="control-label">Result</label>
                	<textarea class="form-control"rows="5"name="results"required></textarea>
                </div>
                <div class="form-group">
                	<label class="control-label">Additional Information</label>
                	<textarea class="form-control"rows="5"name="add_info"required></textarea>
                </div>
                <div class="form-group">
                	<button type="submit"class="btn btn-primary">Send</button>
                </div>
            </form>
        </div>
        <div class="container"id="lab_results"></div>
    </div>
    </body>
    </html>
    <?php
}else{
    redirect(base_url());
}
?>
<script type="text/javascript">
$(function(){
	$('#lab_test').show();
	$('#fill_results').hide();
	$('#lab_results').hide();
	$('#t').click(function(){
		$('#lab_test').show();
		$('#fill_results').hide();
		$('#lab_results').hide();
	});
	$('#f_r').click(function(){
		$('#lab_test').hide();
		$('#fill_results').show();
		$('#lab_results').hide();
	});
	$('#v_r').click(function(){
		$('#lab_test').hide();
		$('#fill_results').hide();
		$('#lab_results').show();

		$.ajax({
			url:'http://localhost/egertonmed/index.php/lab/get_results',
			type:'POST',
			data:{'patient_id':<?php echo $patient_id;?>},
			success:function(msg){
				$('#lab_results').html(msg);
			},
			error:function(){
				alert('Something went wrong!');
			}
		});
	});
});
</script>
<style>
#test{
	padding:10px;
	margin:10px;
	border:1px solid #454545;
	border-radius:3px;
	/*background:*/
} 
#add_info{
	padding:10px;
	margin:10px;
	border:1px solid #454545;
	border-radius:3px;
	/*background:*/
}   
#lab_menu{
	background:#0066CC;
	padding:10px
} 
#lab_menu li{
	display:inline;
}
#lab_menu li a{
	color:#ffffff;
	padding:10px;
	text-decoration:none;
}
#lab_menu li a:hover{
	background:#000066;
}
</style>










