<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){

	$departments=array('','Medical','Pharmacy','Nutrition','Morgue','Records','Ward');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Egerton University Medical Department</title>
	<script type="text/javascript"src></script>
<!--
<https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css.map
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/FontAwesome.otf
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.eot
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.svg
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.ttf
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.woff
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/fonts/fontawesome-webfont.woff2/>-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="../<?php base_url()?>../js/script.js"></script>
</head>
<body>
<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
	      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/admin/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/admin/employees'?>">Employees</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('adm_name').' ';?>
                            </a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    	</header>
<div class="container content">    	
<div class="container"id="new_emp_div">
	<div class="container"><span class="req">*</span>&nbsp;Required fields!</div>
	<div class="container"><?php echo $this->session->flashdata('err_msg');?></div>
	<form action="<?php echo base_url('index.php/admin/add_employee');?>"method="POST"id="new_emp">
		<div class="container row">
		<div class="form-group col-md-4">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Name</label>
			<input type="text"class="col-sm-8 form-control"id="name"name="name"required/>
		</div>
		<div class="form-group col-md-4">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Phone</label>
			<input type="text"class="col-sm-8 form-control"id="phone"name="phone"required/>
		</div>
		<div class="form-group col-md-4">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">E_mailAddress</label>
			<input type="text"class="col-sm-8 form-control"id="email"name="email"required/><span class="warn"></span>
		</div>
		</div>
	</form>
</div>
</div>

</body>
</html>
<?php
}else{
    redirect(base_url());
}
?>
<script type="text/javascript">
	$(function(){
		var r_email=/([\w\-]+\@[\w\-]+\.[\w\-]+)/;
		
	});
</script>