<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<html>
	<head>
		<title>Egerton University Medical Department</title>
		<!--<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->
		<link rel="stylesheet" href="<?php base_url('index.php')?>css/bootstrap.css"/>
		<link rel="stylesheet" href="<?php base_url('index.php')?>css/style.css"/>

		<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>-->
		<script src="<?php base_url('index.php')?>js/bootstrap.min.js"></script>

	<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
	<script src="<?php base_url('index.php')?>js/jquery.js"></script>
	<script src="<?php base_url('index.php')?>js/script.js"></script>
	</head>
	<body>
	<div class="conatiner">Egerton University Medical Department</div>
		<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="./">Home</a></li>
                        	
                        </ul>
          			</nav>
        		</div>
      		</div>
    	</header>
    	<div class="container-main">	
    	<div class="conatiner"id="loginDiv">
    		<form action="<?php echo base_url('index.php/home/login')?>"method="POST"id="loginForm">
    			<div class="container">Enter your login details</div>
    			<span class="warn"><?php echo $this->session->flashdata('msg')?></span>
    			<div class="form-group">
    				<label class="control-label"for="username">Username</label>
    				<input type="text"name="username"class="form-control"placeholder="Username / E-mail"required/>
    			</div>
    			<div class="form-group">
    				<label class="control-label"for="password" >Password</label>
    				<input type="password"name="password"class="form-control"placeholder="Password"required/>
    			</div>
                        <div class="form-group">
    				<label class="control-label"for="password" >User type</label>
                                <select name="user_type"class="form-control"required>
                                    <option></option>
                                    <option>Admin</option>
                                    <option>Doctor</option>
                                    <option>Nurse</option>
                                    <option>Records Officer</option>
                                    <option>Pharmacist</option>
                                    <!-- <option>Nutritionist</option> -->
                                    <option>Lab Officer</option>
                                    <!--<option>Finance Officer</option> -->
                                </select>
    			</div>
    			<div class="form-group">
    				<button type="submit"class="btn btn-default">Login</button>
    			</div>
    		</form>
    	</div>
    	</div>
    	<div class="container">
    		<?php if(!empty($this->session->userdata('adm_name'))){
    					echo '<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>'.$this->session->userdata('adm_name');
    			  }
    			
    		?>
    	</div>
	</body>
</html>