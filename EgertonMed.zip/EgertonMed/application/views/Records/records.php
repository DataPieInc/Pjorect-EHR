<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('r_name'))||isset($_SESSION['r_name'])){


?>
<!DOCTYPE html>
<html>
<head>
	<title>Medical Department</title>
	<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="../<?php base_url()?>../js/script.js"></script>
</head>
<body>
<?php 
	/*foreach($rows as $r){
		$user=array('adm_name'=>$r->username,'email'=>$r->email);
		//echo $r->username.' '.$r->password;
		$this->session->set_userdata($user);
	}*/
	echo $this->session->userdata('r_name');
?>
<div class="container">
	<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/records/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/records/show_records'?>">Records</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('r_name');?></a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    </header>
</div>
    <div class="container content">
        <div class="container row">
            <div class="col-md-6 col-sm-6">
                <a href="<?php echo base_url('index.php/records/new_patient')?>" class="btn btn-success">Add new patient</a>
            </div>
            <!--<div class="col-md-6 col-sm-6 search">
                <form class=""action="<?php //echo base_url('index.php/records/search_pat')?>"method="POST"id="search_">
                    <div class="col-sm-10">    
                        <input type="text"name="pat_key"class="form-control input-sm key" placeholder="Search"required/>
                    </div>
                    <div class="col-sm-2">     
                        <button class="btn btn-success"type="submit">Search<span class="glypicon glyphicon-lens"></span></button>
                    </div>    
                </form>
            </div> -->   
        </div><br/>
        <div class="container"id="records_table">
        
        <?php
        echo $this->session->flashdata('err_entry');
        if(!empty($res)){
            echo'<table class="table table-striped table-bordered table-responsive">
            <tr><th>Name</th><th>Gender</th><th>Patient id</th><th></th><th></th></tr>';
            foreach($res as $r){
                if(isset($r->student_id)){
                    $pat_id=$r->student_id;
                }else if(isset($r->nat_id)){
                    $pat_id=$r->nat_id;
                }
                echo"<tr><td>".$r->name."</td><td>".$r->gender."</td><td>".$pat_id."</td></tr>";
            }
            echo "</table>";
        }else{
            echo"<div class='container'>No records</div>";
        }
        ?>
        </div>
    </div>
</body>
</html>
<?php
}else{
    redirect(base_url());
}