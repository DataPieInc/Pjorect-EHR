<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('r_name'))||isset($_SESSION['r_name'])){


?>
<!DOCTYPE html>
<html>
<head>
	<title>Medical Department</title>
	<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="../<?php base_url()?>../js/script.js"></script>
</head>
<body>
<?php 
	/*foreach($rows as $r){
		$user=array('adm_name'=>$r->username,'email'=>$r->email);
		//echo $r->username.' '.$r->password;
		$this->session->set_userdata($user);
	}*/
	echo $this->session->userdata('r_name');
?>
<div class="container">
	<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/admin/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/records/show_records'?>">Records</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('r_name');?></a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    </header>
</div>
    <div class="container content">
    <h1>New Patient</h1>
       <div class="container"><span class="req">*</span>&nbsp;Required fields!</div>
        <div class="container"><?php  echo $this->session->flashdata('err_entry');?></div>
    <form action="<?php echo base_url('index.php/records/add_record');?>"method="POST"id="new_emp">
            <div class="row">
        <div class="col-lg-4">
                    <div class="form-group">
            <span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Name</label>
            <input type="text"class="col-sm-8 form-control"id="name"name="name"required/>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group">
            <span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Age</label>
            <input type="text"class="col-sm-8 form-control"id="age"name="age"required/>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group">
            <span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Gender</label>
                        <select class="col-sm-8 form-control"name="gender"required>
                            <option></option><option>Male</option><option>Female</option>
                        </select><span class="warn"></span>
                    </div>    
        </div>
                
            </div>
            <div class="container row">
                <div class="col-lg-4">
                    <div class="form-group">
            <span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Patient Type</label>
                        <select class="col-sm-8 form-control"name="pat_type"id="pat_type"required>
                            <option></option><option>Student</option><option>Non-Student</option>
                        </select><span class="warn"></span>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group">
            <span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Visit Type</label>
                        <select class="col-sm-8 form-control"name="visit_type"required>
                            <option></option><option>Sick Visit</option><option>Emergency</option>
                            <option>Routine Checkup</option><option>Counselling</option><option>Vaccination</option><option>Referal</option>
                        </select><span class="warn"></span>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group">
            <label class="control-label"><span class="req">*</span>Next Of Kin Phone Number</label>
            <input type="text"class="form-control"id="kin_no"name="kin_no"required/>
                    </div>    
        </div>
            </div>
        <div class="container row">
           <div class="col-lg-4">
                    <div class="form-group">
            <label class="control-label"><span class="req">*</span>Relative</label>
            <input type="text"class="form-control"id="kin_no"name="kin_name"required/>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group"id="stud_id">
                    <label class="control-label"><span class="req">*</span>Student Id No.</label><input type="text"class="form-control"id="stud_idno"name="stud_idno"/>
                    </div> 
                    <div class="form-group"id="pat_id">
                    <label class="control-label"><span class="req">*</span>National Id No.</label><input type="text"class="form-control"id="pat_idno"name="pat_idno"/>
                    </div>    
        </div>
        <div class="col-lg-4">
                    <div class="form-group"id="price">
                    <label class="control-label">Registration Fee</label>'+
            '<input type="text"class="form-control"id="reg_price"name="reg_price"value="100"readonly/>
                    </div>    
        </div>
        </div>
        <div class="row container">
        <div class="col-lg-12">
                    <div class="form-group">
            <input type="submit"class="btn btn-primary"name="submit"value="Submit"/>
                    </div>    
        </div>
            </div>
            </div>
            
        </form>

    </div>
</body>
</html>
<?php
}else{
    redirect(base_url());
}
?>
<script type="text/javascript">
$(function(){
    $('#price').hide();
    $('#pat_id').hide();
    $('#stud_id').hide();
    $('#pat_type').on('change',function(){
        var type=$('#pat_type').val();
        if(type=='Student'){
             $('#price').hide();
            $('#pat_id').hide();
            $('#stud_id').show();
        }else if(type=='Non-Student'){
            $('#price').show();
            $('#pat_id').show();
            $('#stud_id').hide();
        }else{
             $('#price').hide();
            $('#pat_id').hide();
            $('#stud_id').hide();
        }
    });
});
</script>