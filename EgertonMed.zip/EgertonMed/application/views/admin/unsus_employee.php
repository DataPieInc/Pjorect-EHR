<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){


?>
<!DOCTYPE html>
<html>
<head>
	<title>Medical Department</title>
	<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="<?php base_url('index.php')?>../js/script.js"></script>
</head>
<body>
<?php 
	/*foreach($rows as $r){
		$user=array('adm_name'=>$r->username,'email'=>$r->email);
		//echo $r->username.' '.$r->password;
		$this->session->set_userdata($user);
	}*/
	echo $this->session->userdata('adm_name');
?>
<div class="container">
	<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/admin/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/admin/employees'?>">Employees</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('adm_name');?></a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    </header>
</div>
    <div class="container main_">
        <?php 
        foreach($row as $r){
            echo'<div class="container"id="confirm"><br/><br/><br/><br/><p>Are you sure you want to lift '.$r->name.'\'s suspension?<br/>'
                 . '<a href="'.base_url('index.php').'/admin/unsuspend/'.$r->id.'"class="btn btn-success">Yes</a>&nbsp;'
                    . '<a href="'.base_url('index.php').'/admin/employees"class="btn btn-warning">No</a></p></div>';
        }
        ?>
    </div>
</body>
</html>
<?php
}else{
    redirect(base_url());
}