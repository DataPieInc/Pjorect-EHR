<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){

	$departments=array('','Medical','Pharmacy','Records','Lab');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Egerton University Medical Department</title>
	<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="../<?php base_url()?>../js/script.js"></script>
</head>
<body>
<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
	      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/admin/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/admin/employees'?>">Employees</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('adm_name').' ';?>
                            </a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    	</header>
<div class="container content">    	
<div class="container"id="new_emp_div">
	<div class="container"><span class="req">*</span>&nbsp;Required fields!</div>
        <div class="container"><?php  echo $this->session->flashdata('err_msg');?></div>
	<form action="<?php echo base_url('index.php/admin/add_employee');?>"method="POST"id="new_emp">
            <div class="row">
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Name</label>
			<input type="text"class="col-sm-8 form-control"id="name"name="name"required/>
                    </div>    
		</div>
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Phone</label>
			<input type="text"class="col-sm-8 form-control"id="phone"name="phone"required/>
                    </div>    
		</div>
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">E-mailAddress</label>
			<input type="text"class="col-sm-8 form-control"id="email"name="email"required/><span class="warn"></span>
                    </div>    
		</div>
                <div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Gender</label>
                        <select class="col-sm-8 form-control"name="gender">
                            <option></option><option>Male</option><option>Female</option>
                        </select><span class="warn"></span>
                    </div>    
		</div>
            </div>
            <div class="container row">
                <div class="col-lg-4">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">HomeAddress</label>
			<input type="text"class="col-sm-8 form-control"name="h_address"required/>
                    </div>
                </div>
                <!--<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">ID Number</label>
			<input type="text"class="col-sm-8 form-control"name="nat_id"required/>
                    </div>
                </div>-->
		<div class="col-lg-4">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Name of kin</label>
			<input type="text"class="col-sm-8 form-control"id="kin_name"name="kin_name"required/>
                    </div>    
		</div>
		<div class="col-lg-4">
                    <div class="form-group">
			<label class="col-md-4 control-label"><span class="req">*</span>Next Of Kin Phone Number</label>
			<input type="text"class="col-sm-8 form-control"id="kin_no"name="kin_no"required/>
                    </div>    
		</div>
            </div>
            <div class="container row">
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Department</label>
			<select class="col-sm-8 form-control"id="dept"name="dept"required>
				<?php
				foreach($departments as $d){
					echo'<option>'.$d.'</option>';
				}
				?>
			</select>
                    </div>    
		</div>
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Position</label>
			<select class="col-sm-8 form-control"id="pos"name="pos"required>
				
			</select>
                    </div>    
		</div>
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Date Of Birth</label>
			<input type="text"class="col-sm-8 form-control"name="dob"required/>
                    </div>    
		</div>
		<div class="col-lg-3">
                    <div class="form-group">
			<span class="req">*</span>&nbsp;<label class="col-md-4 control-label">Date Of Recruitment</label>
			<input type="text"class="col-sm-8 form-control"name="dor"required/>
                    </div>    
		</div>    
		</div>
            </div>
            <div class="row container">
		<div class="col-lg-12">
                    <div class="form-group">
			<input type="submit"class="btn btn-primary"name="submit"value="Submit"/>
                    </div>    
		</div>
            </div>
        </form>
</div>
</div>
</body>
</html>
<?php
}else{
    redirect(base_url());
}
?>
<script type="text/javascript">
	$(function(){
		/*$('#new_emp').on('submit',function(e){
			e.preventDefault();
			$('.warn').html('');
			var r_email=/([\w\-]+\@[\w\-]+\.[\w\-]+)/;
			if(!r_email.test($('#email').val())){
				$('.warn').html('Incorrect E-mail formart!');
				return false;
			}/*else if(){

			}	*/
		//});
	});
</script>