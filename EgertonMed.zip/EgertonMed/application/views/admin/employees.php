<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

if(!empty($this->session->userdata('adm_name'))||isset($_SESSION['adm_name'])){


?>
<!DOCTYPE html>
<html>
<head>
	<title>Egerton University Medical Department</title>
	<script type="text/javascript"src></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/bootstrap.css"/>
		<link rel="stylesheet" href="../<?php base_url('index.php')?>../css/style.css"/>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
		<script src="../<?php base_url('index.php')?>../js/bootstrap.min.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="../<?php base_url('index.php')?>../js/jquery.js"></script>
	<script src="../<?php base_url('index.php')?>../js/script.js"></script>
</head>
<body>
<header role="banner" class="navbar navbar-fixed-top navbar-inverse">
      		<div class="container">
        		<div class="navbar-header">
          			<button data-toggle="collapse-side" data-target=".side-collapse" data-target-2=".side-collapse-container" type="button" class="navbar-toggle pull-left"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        		</div>
        		<div class="navbar-inverse side-collapse in">
          			<nav role="navigation" class="navbar-collapse">
            			<ul class="nav navbar-nav">
            				<li><a href="<?php echo base_url('index.php').'/admin/dashboard'?>">Home</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/admin/employees'?>">Employees</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>">Logout</a></li>
                        	<li><a href="<?php echo base_url('index.php').'/logout/logout_user'?>"><?php echo $this->session->userdata('adm_name').' ';?>
                            </a></li>
                        </ul>
          			</nav>
        		</div>
      		</div>
    	</header>
    <br/><br/><br/><br/>
        <div class="container content">
        <div class="container row">
            <div class="col-md-6 col-sm-6">
                <a href="<?php echo base_url('index.php/admin/new_employee')?>" class="btn btn-success">Add new employee</a>
            </div>
            <!-- <div class="col-md-6 col-sm-6 search">
                <form class=""action="<?php //echo base_url('index.php/admin/search_emp')?>"method="POST"id="search_">
                    <div class="col-sm-10">    
                        <input type="text"name="emp_key"class="form-control input-sm key" placeholder="Search"required/>
                    </div>
                    <div class="col-sm-2">     
                        <button class="btn btn-success"type="submit">Search<span class="glypicon glyphicon-lens"></span></button>
                    </div>    
                </form>
            </div> -->   
        </div><br/>
    	<div class="container"id="employees">

    		<?php 
            //echo $this->session->flashdata('msg').'<br/>';
                if(isset($rows)&&count($rows)!=0){
    		echo'<table class="table table-striped table-responsive table-condensed table-bordered"id="emp_table"><tr class="active"><th>Name</th>'
                . '<th>Department</th><th>Position</th><th>Phone No.</th><th>Actions</th></tr>';
    		foreach ($rows as $r) {
                    if($r->status=="ACTIVE"){
                        $status="Suspend";
                    }else if($r->status=="INACTIVE"){
                        $status="Unsuspend";    
                    }
                    echo '<tr><td>'.$r->name.'</td><td>'.$r->department.'</td><td>'.$r->position.'</td><td>'.
                                $r->phone.'</td><td><a href="'.base_url('index.php/admin/sus_employee').'/'.$r->id.'/'.$status.'"class="btn btn-warning btn-xs suspend"id="'.$r->id.'">'.$status.'</a>&nbsp;<a href="'.base_url('index.php/admin/del_employee').'/'.$r->id.'"class="btn btn-danger btn-xs delete"id="'.$r->id.'">'
                                . 'Delete</a></td></tr>';
    		}
            //echo $this->session->flashdata('msg').'<br/>';
    		echo"</table>";
                }else{
                    echo'<div>Empty </div>';
                }
    		?>
    	</div>
        </div>

</body>
</html>
<script type="text/javascript">
$(function(){
   $('#search_').on('submit',function(e){
            e.preventdefault();
            alert('a');
    }); 
    $('.key').keyup(function(){
        var key=$('.key').val();
        //alert(key);
        $.ajax({
            url:'http://localhost/egertonmed/index.php/admin/search_emp',
            type:'POST',
            data:{'key':key},
            success:function(msg){
                //alert(msg);
                $('#employees').html(msg);
            },
            error:function(){
                alert('Something went wrong!');
            }
        });
    });
});
</script>
<?php
}else{
    redirect(base_url());
}