<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nurse_ extends CI_Model
{
    public function save_measurements($update,$patient_id){
        $this->db->set($update);
        $this->db->where(array('patient_id'=>$patient_id,'attended_to'=>'NO'));
        return $this->db->update('patient_history',$update);
    }
}

