<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Records_ extends CI_Model{
	public function add_student($pat_data){
		$this->db->select('*');
        $this->db->from('patients');
        $this->db->where("name='".$pat_data['name']."'AND student_id='".$pat_data['student_id']."'");
        $exists=$this->db->get();
        if(!$exists->num_rows()>0){
        	$pat_adde=$this->db->insert('patients',$pat_data);
        	if($pat_data){
        		return true;
        	}else{
        		return false;
        	}
        }else{
        	return false;
        }
	}
	public function add_non_student($pat_data){
		$this->db->select('*');
        $this->db->from('patients');
        $this->db->where("name='".$pat_data['name']."'AND nat_id='".$pat_data['nat_id']."'");
        $exists=$this->db->get();
        if(!$exists->num_rows()>0){
        	$pat_added=$this->db->insert('patients',$pat_data);
        	if($pat_added){
        		return true;
        	}else{
        		return false;
        	}
        }else{
        	return false;
        }
	}
	public function insert_pat_history($history_data){
        $history=$this->db->insert('patient_history',$history_data);
        if($history){
            return true;
        }else{
            return false;
        }
    }
}
