<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**'name="'.$emp_data['name'].'" AND phone="'.$emp_data['phone'].'"'*/

class Admin_ extends CI_Model{
    public function add_emp($emp_data){
        $this->db->select('*');
        $this->db->from('employees');
        $this->db->where("name='".$emp_data['name']."'AND phone='".$emp_data['phone']."'");
        $exits=$this->db->get();
        if($exits->num_rows()>0){
            return false;
        }elseif($exits->num_rows()==0){
            $user_added=$this->db->insert('employees',$emp_data);
            if($user_added){
                return true;
            }else{
                return false;
            }
        }
        
    }
    public function suspend($emp_id){
        $data=array('status'=>'INACTIVE');
        $this->db->set($data);
        $this->db->where('id',$emp_id);
        $this->db->update('employees',$data);
    }
    public function unsuspend($emp_id){
        $data=array('status'=>'ACTIVE');
        $this->db->set($data);
        $this->db->where('id',$emp_id);
        $this->db->update('employees',$data);
    }
    public function delete_emp($emp_id){
        $this->db->where('id',$emp_id);
        $this->db->delete('employees');
    }
    public function search_emp($key){
        //$sql="SELECT * FROM employees WHERE name LIKE '%".$KEY."'%";
        /*$this->db->select('*');
        $this->db->like('name',$key);
        $data=  $this->db->get('employees')->result();*/
        //$data=$this->db->query($sql);
        //$this->db->select('name,id,phone,email FROM employees WHERE name LIKE \'%'.$key.'%\'ORDER BY name', FALSE);
       /* $this->db->select('*')->from('employees'); 
        $this->db->like('name',$key,'after'); 
        $this->db->or_like('name',$key,'before'); 
        $query = $this->db->get(); */ 
        return $this->db->select('*')->from('employees')->like('name',$key)->get()->result();
        //return $query->result();
        //return $this->db->get();
    }
}
