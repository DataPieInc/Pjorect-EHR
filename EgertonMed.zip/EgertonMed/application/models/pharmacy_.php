<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pharmacy_ extends CI_Model
{
    public function prescription_seen($update,$pharmacist_id){
        $this->db->set(array('status'=>'Served','pharmacist_id'=>$pharmacist_id));
        $this->db->where($update);
        return $this->db->update('pharmacy',array('status'=>'Served','pharmacist_id'=>$pharmacist_id));
    }
	public function update_patient_history($patient_id){
		$this->db->set(array('to_pharmacy'=>'Served'));
		$this->db->where(array('patient_id'=>$patient_id,'to_pharmacy'=>'Pending'));
		return $this->db->update('patient_history',array('to_pharmacy'=>'Served'));
	}
}

