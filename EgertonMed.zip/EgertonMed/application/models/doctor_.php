<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctor_ extends CI_Model
{
    public function send_to_lab($pat_id,$doctor_id,$tests,$additional_info){
        $doctor=$this->db->get_where('employees',array('id'=>$doctor_id))->result();
        foreach ($doctor as $d) {
            $doctor_name=$d->name;
            //$u_id=$r->id;
        }
        $patient=$this->db->get_where('patient_history',array('patient_id'=>$pat_id));
        if($patient->num_rows()==0){
            $patient=$this->db->get_where('patient_history',array('patient_id'=>$pat_id))->result();
        }
        else{
            $patient=$this->db->get_where('patient_history',array('patient_id'=>$pat_id))->result();
        }
        /*$doctor=$this->db->query("SELECT * FROM employees WHERE id='".$doctor_id."'");
        $pat=$this->db->query("SELECT * FROM patients WHERE student_id='".$pat_id."'");
        if($pat->num_rows()==0){
            $pat=$this->db->query("SELECT * FROM patients WHERE nat_id='".$pat_id."'");
        }*/

        foreach ($patient as $p){
            $pat_name=$p->name;
        }
        $lab_details=array('patient_id'=>$pat_id,'patient_name'=>$pat_name,'doctor_id'=>$doctor_id,'doctor_name'=>$doctor_name,'tests'=>$tests,
                            'additional_info'=>$additional_info,'date_sent'=>gmstrftime("%Y-%m-%d %H:%M:%S",time()+60*60*-8));
        $sent_to_lab=$this->db->insert('lab_exams',$lab_details);
        if($sent_to_lab){
            return true;
        }else{
            return false;
        }
    }
    public function add_patient_history($pat_data,$pat_id){
        $this->db->set($pat_data);
        $this->db->where(array('patient_id'=>$pat_id,'attended_to'=>'NO'));
        $update=$this->db->update('patient_history',$pat_data);
        if($update){
            return true;
        }else{
            return false;
        }
    }
    public  function diagnosis($update,$patient_id){
        $this->db->set($update);
        $this->db->where(array('patient_id'=>$patient_id,'attended_to'=>'NO'));
        return $this->db->update('patient_history',$update);
    }
    public function treatment($update,$patient_id){
        $this->db->set($update);
        $this->db->where(array('patient_id'=>$patient_id,'attended_to'=>'NO'));
        return $this->db->update('patient_history',$update);
    }
    public function prescription($prescription){
        return  $this->db->insert('pharmacy',$prescription);
    }
    public function discharge($update,$patient_id){
        $this->db->set($update);
        $this->db->where(array('patient_id'=>$patient_id));
        return $this->db->update('patient_history',$update);
    }
}