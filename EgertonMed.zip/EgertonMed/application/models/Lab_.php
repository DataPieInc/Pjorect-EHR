<?php

/**
 * Created by PhpStorm.
 * User: Derick Oduor
 * Date: 5/28/2017
 * Time: 5:43 PM
 */
class Lab_ extends CI_Model
{
    public function lab_exam_seen($lab_update){
        /*foreach($lab_update as $l){
            $pat_id=$l['patient_id'];
        }*/
        $this->db->set($lab_update);
        $this->db->where('patient_id',$lab_update['patient_id']);
        return $this->db->update('lab_exams',$lab_update);
    }
    public function lab_results($lab_result_data){
        return $this->db->insert('lab_reports',$lab_result_data);
    }
    public function update_lab_table($patient_id){
        
        $this->db->set(array('status'=>'Done'));
        $this->db->where(array('patient_id'=>$patient_id,'status'=>'Processing'));
        return $this->db->update('lab_exams',array('status'=>'Done'));
    }
    public function update_pat_history($update_history,$patient_id){
        $this->db->set($update_history);
        $this->db->where(array('patient_id'=>$patient_id,'attended_to'=>'NO'));
        return $this->db->update('patient_history',$update_history);
    }
}